package com.codearti.serviceorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
