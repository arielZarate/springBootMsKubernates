package com.codearti.servicenotify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceNotifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceNotifyApplication.class, args);
	}

}
